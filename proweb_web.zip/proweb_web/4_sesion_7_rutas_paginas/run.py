#import flask
from flask import Flask, render_template


#variable del entrno
app = Flask(__name__)

#crear ruta
@app.route('/')
def HOME():
    return render_template('paginas/home.html')

@app.route('/opc_uno')
def OPC_1():
    return render_template('paginas/opc_1.html')




#iniciar run
if __name__=='__main__':
    app.run(debug=True)
