#import flask
from flask import Flask, render_template


#variable del entrno
app = Flask(__name__)

#crear ruta
@app.route('/')
def Prueba():
    return render_template('layout.html')





#iniciar run
if __name__=='__main__':
    app.run(debug=True)
