#import flask
from flask import Flask

#variable del entrno
app = Flask(__name__)

#crear ruta


#iniciar run
if __name__=='__main__':
    app.run(debug=True)
