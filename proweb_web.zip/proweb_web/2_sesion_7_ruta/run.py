#import flask
from flask import Flask

#variable del entrno
app = Flask(__name__)

#crear ruta
@app.route('/')
def Prueba():
    return ' esto es una ruta  basica'





#iniciar run
if __name__=='__main__':
    app.run(debug=True)
